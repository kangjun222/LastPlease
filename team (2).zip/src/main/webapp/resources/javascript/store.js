function mouseout(val){
    if(val == '1'){
        $('#ebbox2').css('opacity','1');
        $('#ebbox3').css('opacity','1');
        $('#ebbox4').css('opacity','1');
        $('#ebbox5').css('opacity','1');
        $('#ebbox6').css('opacity','1');
        $('#ebbox7').css('opacity','1');
        $('#ebbox8').css('opacity','1');
    }

    if(val == '2'){
        $('#ebbox1').css('opacity','1');
        $('#ebbox3').css('opacity','1');
        $('#ebbox4').css('opacity','1');
        $('#ebbox5').css('opacity','1');
        $('#ebbox6').css('opacity','1');
        $('#ebbox7').css('opacity','1');
        $('#ebbox8').css('opacity','1');
    }

    if(val == '3'){
        $('#ebbox1').css('opacity','1');
        $('#ebbox2').css('opacity','1');
        $('#ebbox4').css('opacity','1');
        $('#ebbox5').css('opacity','1');
        $('#ebbox6').css('opacity','1');
        $('#ebbox7').css('opacity','1');
        $('#ebbox8').css('opacity','1');
    }

    if(val == '4'){
        $('#ebbox1').css('opacity','1');
        $('#ebbox2').css('opacity','1');
        $('#ebbox3').css('opacity','1');
        $('#ebbox5').css('opacity','1');
        $('#ebbox6').css('opacity','1');
        $('#ebbox7').css('opacity','1');
        $('#ebbox8').css('opacity','1');
    }

    if(val == '5'){
        $('#ebbox1').css('opacity','1');
        $('#ebbox2').css('opacity','1');
        $('#ebbox3').css('opacity','1');
        $('#ebbox4').css('opacity','1');
        $('#ebbox6').css('opacity','1');
        $('#ebbox7').css('opacity','1');
        $('#ebbox8').css('opacity','1');
    }

    if(val == '6'){
        $('#ebbox1').css('opacity','1');
        $('#ebbox2').css('opacity','1');
        $('#ebbox3').css('opacity','1');
        $('#ebbox4').css('opacity','1');
        $('#ebbox5').css('opacity','1');
        $('#ebbox7').css('opacity','1');
        $('#ebbox8').css('opacity','1');
    }

    if(val == '7'){
        $('#ebbox1').css('opacity','1');
        $('#ebbox2').css('opacity','1');
        $('#ebbox3').css('opacity','1');
        $('#ebbox4').css('opacity','1');
        $('#ebbox5').css('opacity','1');
        $('#ebbox6').css('opacity','1');
        $('#ebbox8').css('opacity','1');
    }
    if(val == '8'){
        $('#ebbox1').css('opacity','1');
        $('#ebbox2').css('opacity','1');
        $('#ebbox3').css('opacity','1');
        $('#ebbox4').css('opacity','1');
        $('#ebbox5').css('opacity','1');
        $('#ebbox6').css('opacity','1');
        $('#ebbox7').css('opacity','1');
    }
    if(val == '9'){
        $('#ebbox10').css('opacity','1');
        $('#ebbox11').css('opacity','1');
        $('#ebbox12').css('opacity','1');
        $('#ebbox13').css('opacity','1');
        $('#ebbox14').css('opacity','1');
        $('#ebbox15').css('opacity','1');
        $('#ebbox16').css('opacity','1');
    }

    if(val == '10'){
        $('#ebbox9').css('opacity','1');
        $('#ebbox11').css('opacity','1');
        $('#ebbox12').css('opacity','1');
        $('#ebbox13').css('opacity','1');
        $('#ebbox14').css('opacity','1');
        $('#ebbox15').css('opacity','1');
        $('#ebbox16').css('opacity','1');
    }

    if(val == '11'){
        $('#ebbox9').css('opacity','1');
        $('#ebbox10').css('opacity','1');
        $('#ebbox12').css('opacity','1');
        $('#ebbox13').css('opacity','1');
        $('#ebbox14').css('opacity','1');
        $('#ebbox15').css('opacity','1');
        $('#ebbox16').css('opacity','1');
    }

    if(val == '12'){
        $('#ebbox9').css('opacity','1');
        $('#ebbox10').css('opacity','1');
        $('#ebbox11').css('opacity','1');
        $('#ebbox13').css('opacity','1');
        $('#ebbox14').css('opacity','1');
        $('#ebbox15').css('opacity','1');
        $('#ebbox16').css('opacity','1');
    }

    if(val == '13'){
        $('#ebbox9').css('opacity','1');
        $('#ebbox10').css('opacity','1');
        $('#ebbox11').css('opacity','1');
        $('#ebbox12').css('opacity','1');
        $('#ebbox14').css('opacity','1');
        $('#ebbox15').css('opacity','1');
        $('#ebbox16').css('opacity','1');
    }

    if(val == '14'){
        $('#ebbox9').css('opacity','1');
        $('#ebbox10').css('opacity','1');
        $('#ebbox11').css('opacity','1');
        $('#ebbox12').css('opacity','1');
        $('#ebbox13').css('opacity','1');
        $('#ebbox15').css('opacity','1');
        $('#ebbox16').css('opacity','1');
    }

    if(val == '15'){
        $('#ebbox9').css('opacity','1');
        $('#ebbox10').css('opacity','1');
        $('#ebbox11').css('opacity','1');
        $('#ebbox12').css('opacity','1');
        $('#ebbox13').css('opacity','1');
        $('#ebbox14').css('opacity','1');
        $('#ebbox16').css('opacity','1');
    }
    if(val == '16'){
        $('#ebbox9').css('opacity','1');
        $('#ebbox10').css('opacity','1');
        $('#ebbox11').css('opacity','1');
        $('#ebbox12').css('opacity','1');
        $('#ebbox13').css('opacity','1');
        $('#ebbox14').css('opacity','1');
        $('#ebbox15').css('opacity','1');
    }
}

function mouseon(val){
    if(val == '1'){
        $('#ebbox2').css('opacity','0.5');
        $('#ebbox3').css('opacity','0.5');
        $('#ebbox4').css('opacity','0.5');
        $('#ebbox5').css('opacity','0.5');
        $('#ebbox6').css('opacity','0.5');
        $('#ebbox7').css('opacity','0.5');
        $('#ebbox8').css('opacity','0.5');
    }

    if(val == '2'){
        $('#ebbox1').css('opacity','0.5');
        $('#ebbox3').css('opacity','0.5');
        $('#ebbox4').css('opacity','0.5');
        $('#ebbox5').css('opacity','0.5');
        $('#ebbox6').css('opacity','0.5');
        $('#ebbox7').css('opacity','0.5');
        $('#ebbox8').css('opacity','0.5');
    }

    if(val == '3'){
        $('#ebbox1').css('opacity','0.5');
        $('#ebbox2').css('opacity','0.5');
        $('#ebbox4').css('opacity','0.5');
        $('#ebbox5').css('opacity','0.5');
        $('#ebbox6').css('opacity','0.5');
        $('#ebbox7').css('opacity','0.5');
        $('#ebbox8').css('opacity','0.5');
    }

    if(val == '4'){
        $('#ebbox1').css('opacity','0.5');
        $('#ebbox2').css('opacity','0.5');
        $('#ebbox3').css('opacity','0.5');
        $('#ebbox5').css('opacity','0.5');
        $('#ebbox6').css('opacity','0.5');
        $('#ebbox7').css('opacity','0.5');
        $('#ebbox8').css('opacity','0.5');
    }

    if(val == '5'){
        $('#ebbox1').css('opacity','0.5');
        $('#ebbox2').css('opacity','0.5');
        $('#ebbox3').css('opacity','0.5');
        $('#ebbox4').css('opacity','0.5');
        $('#ebbox6').css('opacity','0.5');
        $('#ebbox7').css('opacity','0.5');
        $('#ebbox8').css('opacity','0.5');
    }

    if(val == '6'){
        $('#ebbox1').css('opacity','0.5');
        $('#ebbox2').css('opacity','0.5');
        $('#ebbox3').css('opacity','0.5');
        $('#ebbox4').css('opacity','0.5');
        $('#ebbox5').css('opacity','0.5');
        $('#ebbox7').css('opacity','0.5');
        $('#ebbox8').css('opacity','0.5');
    }

    if(val == '7'){
        $('#ebbox1').css('opacity','0.5');
        $('#ebbox2').css('opacity','0.5');
        $('#ebbox3').css('opacity','0.5');
        $('#ebbox4').css('opacity','0.5');
        $('#ebbox5').css('opacity','0.5');
        $('#ebbox6').css('opacity','0.5');
        $('#ebbox8').css('opacity','0.5');
    }
    if(val == '8'){
        $('#ebbox1').css('opacity','0.5');
        $('#ebbox2').css('opacity','0.5');
        $('#ebbox3').css('opacity','0.5');
        $('#ebbox4').css('opacity','0.5');
        $('#ebbox5').css('opacity','0.5');
        $('#ebbox6').css('opacity','0.5');
        $('#ebbox7').css('opacity','0.5');
    }
    if(val == '9'){
        $('#ebbox10').css('opacity','0.5');
        $('#ebbox11').css('opacity','0.5');
        $('#ebbox12').css('opacity','0.5');
        $('#ebbox13').css('opacity','0.5');
        $('#ebbox14').css('opacity','0.5');
        $('#ebbox15').css('opacity','0.5');
        $('#ebbox16').css('opacity','0.5');
    }

    if(val == '10'){
        $('#ebbox9').css('opacity','0.5');
        $('#ebbox11').css('opacity','0.5');
        $('#ebbox12').css('opacity','0.5');
        $('#ebbox13').css('opacity','0.5');
        $('#ebbox14').css('opacity','0.5');
        $('#ebbox15').css('opacity','0.5');
        $('#ebbox16').css('opacity','0.5');
    }

    if(val == '11'){
        $('#ebbox9').css('opacity','0.5');
        $('#ebbox10').css('opacity','0.5');
        $('#ebbox12').css('opacity','0.5');
        $('#ebbox13').css('opacity','0.5');
        $('#ebbox14').css('opacity','0.5');
        $('#ebbox15').css('opacity','0.5');
        $('#ebbox16').css('opacity','0.5');
    }

    if(val == '12'){
        $('#ebbox9').css('opacity','0.5');
        $('#ebbox10').css('opacity','0.5');
        $('#ebbox11').css('opacity','0.5');
        $('#ebbox13').css('opacity','0.5');
        $('#ebbox14').css('opacity','0.5');
        $('#ebbox15').css('opacity','0.5');
        $('#ebbox16').css('opacity','0.5');
    }

    if(val == '13'){
        $('#ebbox9').css('opacity','0.5');
        $('#ebbox10').css('opacity','0.5');
        $('#ebbox11').css('opacity','0.5');
        $('#ebbox12').css('opacity','0.5');
        $('#ebbox14').css('opacity','0.5');
        $('#ebbox15').css('opacity','0.5');
        $('#ebbox16').css('opacity','0.5');
    }

    if(val == '14'){
        $('#ebbox9').css('opacity','0.5');
        $('#ebbox10').css('opacity','0.5');
        $('#ebbox11').css('opacity','0.5');
        $('#ebbox12').css('opacity','0.5');
        $('#ebbox13').css('opacity','0.5');
        $('#ebbox15').css('opacity','0.5');
        $('#ebbox16').css('opacity','0.5');
    }

    if(val == '15'){
        $('#ebbox9').css('opacity','0.5');
        $('#ebbox10').css('opacity','0.5');
        $('#ebbox11').css('opacity','0.5');
        $('#ebbox12').css('opacity','0.5');
        $('#ebbox13').css('opacity','0.5');
        $('#ebbox14').css('opacity','0.5');
        $('#ebbox16').css('opacity','0.5');
    }
    if(val == '16'){
        $('#ebbox9').css('opacity','0.5');
        $('#ebbox10').css('opacity','0.5');
        $('#ebbox11').css('opacity','0.5');
        $('#ebbox12').css('opacity','0.5');
        $('#ebbox13').css('opacity','0.5');
        $('#ebbox14').css('opacity','0.5');
        $('#ebbox15').css('opacity','0.5');
    }
}

 document.querySelector('#ebradio2').addEventListener('click',function(){
    document.querySelector('#allwrap').style.transform='translate(-1920px)';
});

document.querySelector('#ebradio1').addEventListener('click',function(){
    document.querySelector('#allwrap').style.transform='translate(0)';
});

document.querySelector('#button2').addEventListener('click',function(){
    $("#slide2").css('opacity','1');
    $("#slide1").css('opacity','0.5');
    $("#slide3").css('opacity','0.5');
    $("#slide4").css('opacity','0.5');
    $("#slide5").css('opacity','0.5');
    document.querySelector('.slidewrap').style.transform='translate(-1920px)';
});

document.querySelector('#button3').addEventListener('click',function(){
    $("#slide3").css('opacity','1');
    $("#slide1").css('opacity','0.5');
    $("#slide2").css('opacity','0.5');
    $("#slide4").css('opacity','0.5');
    $("#slide5").css('opacity','0.5');
    document.querySelector('.slidewrap').style.transform='translate(-3840px)'
});

document.querySelector('#button4').addEventListener('click',function(){
    $("#slide4").css('opacity','1');
    $("#slide1").css('opacity','0.5');
    $("#slide2").css('opacity','0.5');
    $("#slide3").css('opacity','0.5');
    $("#slide5").css('opacity','0.5');
    document.querySelector('.slidewrap').style.transform='translate(-5760px)'
});

document.querySelector('#button5').addEventListener('click',function(){
    $("#slide5").css('opacity','1');
    $("#slide1").css('opacity','0.5');
    $("#slide2").css('opacity','0.5');
    $("#slide4").css('opacity','0.5');
    $("#slide3").css('opacity','0.5');
    document.querySelector('.slidewrap').style.transform='translate(-7680px)'
});

document.querySelector('#button1').addEventListener('click',function(){
    $("#slide1").css('opacity','1');
    $("#slide3").css('opacity','0.5');           
    $("#slide2").css('opacity','0.5');
    $("#slide4").css('opacity','0.5');
    $("#slide5").css('opacity','0.5');
    document.querySelector('.slidewrap').style.transform='translate(0px)'
});