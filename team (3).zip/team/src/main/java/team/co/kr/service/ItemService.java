package team.co.kr.service;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import team.co.kr.entity.Item;
import team.co.kr.mapper.ItemMapper;

@Service
public class ItemService {
	@Autowired
	private ItemMapper itmapper;
	
	public int insertItem(Item item) {
		int result = itmapper.insertItem(item);
		
		return result;
	}
	
	public String uploadimg(HttpServletRequest req) {
		
		//cos ���̺귯�� ���� ��밡�ɰ�ü multipartreuqest
		MultipartRequest multi = null;
		int filemaxsize = 10*1024*1024; //10mb
		String savePath = req.getRealPath("resources/upload");
		
		try {
			multi = new MultipartRequest(req, savePath,filemaxsize,"UTF-8",new DefaultFileRenamePolicy());			
		}
		catch (Exception e) {
			return "redirect:/item/addItemForm";
		}
		
		//�����̸���������
		String filename = "";
		File file = multi.getFile("itemimg");//���ε��
		
		if(file != null) {
			String ext = file.getName().substring(file.getName().lastIndexOf(".")+1);
			ext = ext.toUpperCase();
			
			if(ext.equals("JPG") || ext.equals("PNG") || ext.equals("GIF")) {
				filename = file.getName();
			}
			else {
				file.delete();
			}
			
		}
		
		return filename;
	}
	
}
