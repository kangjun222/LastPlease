package team.co.kr.entity;

import lombok.Data;

@Data
public class Audition {
	private String JIWON;
	private String NAME;
	private String PONE;
	private String ADDRESS;
	private String EMAIL;
	private String HEELO;
	private String img;
	private String img1;
	
	
	
}
