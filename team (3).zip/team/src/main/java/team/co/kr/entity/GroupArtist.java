package team.co.kr.entity;

import lombok.Data;

@Data
public class GroupArtist {
	private int idx;
	private String groupname;
	private String ename;
	private String debutbirth;
	private String gmember;
	private String debutsong;
	private String job;
	private String profile;
	private String works;
	private String carrer;
	
}
